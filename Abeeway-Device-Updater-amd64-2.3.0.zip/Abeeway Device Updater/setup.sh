#!/bin/bash

# Relaunch the script in sudo if not already
if [ $(id -u) != "0" ]
then
    sudo "$0" "$@"
    exit $?
fi

BINARY_NAME="Abeeway-Device-Updater"
BINARY_PATH="${BINARY_NAME}"
DESKTOP_FILE_NAME="abeeway-device-updater.desktop"
DESKTOP_FILE_PATH="${DESKTOP_FILE_NAME}"

BINARY_TARGET="/usr/bin"
DESKTOP_TARGET="/usr/share/applications"

copy () {
	###########################################################################
	# Parameters:                                                             #
	#                                                                         #
	# $1: Source                                                              #
	# $2: Target                                                              #
	# $3: Mode                                                                #
	#                                                                         #
	###########################################################################
	source=$1
	target=$2
	mode=$3

	cp $source $target
	echo "Copied ${source} to ${target}"
	chmod $mode "${target}/${source}"
	echo "Set permission for ${target}/${source} to ${mode}" 
}

echo "Copying binary file"
copy $BINARY_PATH $BINARY_TARGET 755
echo "Copying desktop file"
copy $DESKTOP_FILE_PATH $DESKTOP_TARGET 644
